import { Injectable } from '@angular/core';
import { Movie } from '../models/movie.model';
import { Observable,throwError } from 'rxjs';
import {catchError} from 'rxjs/operators';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MovieService {

  private baseUrl ='http://localhost:8765/micro-movie/api/movie/';
  constructor(private httpClient:HttpClient) { }

   getMovies():Observable<Movie[]>{
     return this.httpClient.get<Movie[]>(`${this.baseUrl}`+'getAllMovies')
              .pipe(catchError(this.handleError));
   }

   private handleError(errorResponse:HttpErrorResponse){
     if(errorResponse.error instanceof ErrorEvent){
       console.error('Client Side Error',errorResponse.error.message);
     }
     else{
      console.error('Server Side Error',errorResponse);
     }
     return throwError('There is a problem with the service.We are notified and working on it.Please try again later');
   }
   getMovie(id:string):Observable<Movie>{
     console.log("getMovie"+id);
    return this.httpClient.get<Movie>(`${this.baseUrl}get/${id}`)
              .pipe(catchError(this.handleError));
    //listMovies.find(m=>m.id===id);
  }

   addMovie(movie:Movie):Observable<Movie>{
    return this.httpClient.post<Movie>(`${this.baseUrl}`+'addMovie', movie)
              .pipe(catchError(this.handleError));
   }
   
   updateMovie(id: string, value: any): Observable<Movie> {
    return this.httpClient.put<Movie>(`${this.baseUrl}update/${id}`, value);
  }
  
   deleteMovie(id:string){
      return this.httpClient.delete<void>(`${this.baseUrl}delete/${id}` )
        .pipe(catchError(this.handleError));
   }
  
}
