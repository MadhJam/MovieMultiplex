import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { Allotment } from '../../models/allotment.model';
import { Multiplex } from '../../models/multiplex.model';

@Injectable({
  providedIn: 'root'
})
export class AllotmentService {

  private baseUrl ='http://localhost:8765/micro-multiplex/api/multiplex/';

  constructor(private httpClient:HttpClient) { }
  addMovieAllotment(allot:Allotment):Observable<Allotment>{
    
    return this.httpClient.post<Allotment>(`${this.baseUrl}`+'addAllotment',allot)
              .pipe(catchError(this.handleError));
   }
   private handleError(errorResponse:HttpErrorResponse){
    if(errorResponse.error instanceof ErrorEvent){
      console.error('Client Side Error',errorResponse.error.message);
    }
    else{
     console.error('Server Side Error',errorResponse);
    }
    return throwError('There is a problem with the service.We are notified and working on it.Please try again later');
  }
  getAllotedMultiplexes(movieId:string):Observable<Multiplex[]>{
    return this.httpClient.get<Multiplex[]>(`${this.baseUrl}getAllotmentDetails/${movieId}/`)
              .pipe(catchError(this.handleError));
  }
  
}
