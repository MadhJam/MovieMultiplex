import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Movie } from '../models/movie.model';
import { Observable, of } from 'rxjs';
import { MovieService } from './movie.service';
import { catchError } from 'rxjs/operators';



@Injectable({
  providedIn: 'root'
})
export class MovieListResolverService implements Resolve<Movie[]|string> {
  constructor(private movieService:MovieService) { }
  resolve(route:ActivatedRouteSnapshot,state:RouterStateSnapshot):Observable<Movie[]|string>{
      return this.movieService.getMovies()
        .pipe(
          catchError((error:string)=>of(error))
        );
  }
 
}
