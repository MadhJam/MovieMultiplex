import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { MovieService } from './movie.service';

@Injectable({
  providedIn: 'root'
})
export class MovieDetailsGuardService implements CanActivate {
  constructor(private movieService:MovieService,private route:Router) { }
  canActivate(route:ActivatedRouteSnapshot,state:RouterStateSnapshot):boolean{
    const movieExist=!!this.movieService.getMovie(route.paramMap.get('id'));
    if(movieExist){
      return true;
    }
    else {
      this.route.navigate(['notfound']);
      return false;
    }
  }
}
