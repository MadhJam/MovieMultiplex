import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { MultiplexService } from './multiplex.service';

@Injectable({
  providedIn: 'root'
})
export class MultiplexDetailsGuardService implements CanActivate {
  constructor(private multiplexService:MultiplexService,private route:Router) { }
  canActivate(route:ActivatedRouteSnapshot,state:RouterStateSnapshot):boolean{
    const multiplexExist=!!this.multiplexService.getMultiplex(route.paramMap.get('mId'));
    if(multiplexExist){
      return true;
    }
    else {
      this.route.navigate(['notfound']);
      return false;
    }
  }
}
