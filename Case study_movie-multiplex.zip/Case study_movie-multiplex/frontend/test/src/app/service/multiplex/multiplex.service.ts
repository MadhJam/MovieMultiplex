import { Injectable } from '@angular/core';
import { Observable,throwError } from 'rxjs';
import {catchError} from 'rxjs/operators';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import { Multiplex } from '../../models/multiplex.model';

@Injectable({
  providedIn: 'root'
})
export class MultiplexService {

  private baseUrl ='http://localhost:8765/micro-multiplex/api/multiplex/';
  constructor(private httpClient:HttpClient) { }
  
  getMultiplexes():Observable<Multiplex[]>{
    return this.httpClient.get<Multiplex[]>(`${this.baseUrl}`+'getAllMultiplexes')
             .pipe(catchError(this.handleError));
  }

  private handleError(errorResponse:HttpErrorResponse){
    if(errorResponse.error instanceof ErrorEvent){
      console.error('Client Side Error',errorResponse.error.message);
    }
    else{
     console.error('Server Side Error',errorResponse);
    }
    return throwError('There is a problem with the service.We are notified and working on it.Please try again later');
  }

  getMultiplex(mId:string):Observable<Multiplex>{
    return this.httpClient.get<Multiplex>(`${this.baseUrl}get/${mId}`)
              .pipe(catchError(this.handleError));
    //listMovies.find(m=>m.id===id);
  }

 addMultiplex(multiplex:Multiplex):Observable<Multiplex>{
  return this.httpClient.post<Multiplex>(`${this.baseUrl}`+'register',multiplex)
            .pipe(catchError(this.handleError));
 }
 
 updateMultiplex(mId:string, value: any): Observable<Multiplex> {
  return this.httpClient.put<Multiplex>(`${this.baseUrl}update/${mId}`, value);
}

 deleteMultiplex(mId:string){
    return this.httpClient.delete<void>(`${this.baseUrl}delete/${mId}` )
      .pipe(catchError(this.handleError));
 }

}
