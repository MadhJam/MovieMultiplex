import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpErrorResponse, HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ScreenService {
  
 
  private baseUrl ='http://localhost:8765/micro-multiplex/api/multiplex/';
  constructor(private httpClient:HttpClient) { }

  getScreen(mid:string):Observable<Screen[]>{
    return this.httpClient.get<Screen[]>(`${this.baseUrl}getScreens/${mid}/`)
              .pipe(catchError(this.handleError));
  }
  getScreensToAllot(mid:string):Observable<Screen[]>{
    return this.httpClient.get<Screen[]>(`${this.baseUrl}getScreensToAllot/${mid}/`)
              .pipe(catchError(this.handleError));
  }
  private handleError(errorResponse:HttpErrorResponse){
    if(errorResponse.error instanceof ErrorEvent){
      console.error('Client Side Error',errorResponse.error.message);
    }
    else{
     console.error('Server Side Error',errorResponse);
    }
    return throwError('There is a problem with the service.We are notified and working on it.Please try again later');
  }
  addScreen(mId:string, screenName: String): Observable<Screen> {
    return this.httpClient.post<Screen>(`${this.baseUrl}addScreen/${mId}`, screenName);
  }

}
