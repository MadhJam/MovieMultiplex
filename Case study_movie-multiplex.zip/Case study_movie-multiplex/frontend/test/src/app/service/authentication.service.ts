import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import {map} from 'rxjs/operators';
import { Router } from '@angular/router';
const VALIDATION_URL= "http://localhost:8765/micro-user/api/user/login";

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {


  constructor(private httpClient : HttpClient,private router:Router){

  }

  authenticate(username : string, password : string){
   
    let authToken = "Basic " + window.btoa(username + ":" + password);
    console.log(authToken);
    
  
    let headers = new HttpHeaders({
      Authorization : authToken
     
    });

    return this.httpClient.get(VALIDATION_URL, {headers,params:{username:username,password:password},responseType: 'text' })
    .pipe(map((successData) => {
        console.log("AUTH SUCCESS :" +  successData);
        sessionStorage.setItem("user",username);
        sessionStorage.setItem("token",authToken);
        return successData;
      }),
        map((failureData) => {
        console.log("AUTH FAILED :" +  failureData);
        return failureData;
      })
    );

  }

  // method to return token
  getAuthenticationToken(){
    return sessionStorage.getItem("token");
  }


  isUserLoggedIn(): boolean{
    // if 'user' key is present
    let user = sessionStorage.getItem('user');
    if(user == null)
      return false;
    else
      return true;  
  }

  //  can have method to return type of user

  logout(){
    sessionStorage.removeItem('user');
    sessionStorage.removeItem('token');
    setTimeout(()=> {this.router.navigate(['/movieList']);}, 2000);
  }

}

