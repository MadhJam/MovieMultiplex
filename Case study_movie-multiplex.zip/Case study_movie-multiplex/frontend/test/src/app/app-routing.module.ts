import { Routes, RouterModule } from "@angular/router";
import { MoviesListComponent } from "./movies-list/movies-list.component";
import { MovieListResolverService } from "./service/movie-list-resolver.service";
import { MovieDetailsComponent } from "./movies-list/movie-details/movie-details.component";
import { MovieDetailsGuardService } from "./service/movie-details-guard.service";
import { AddMovieComponent } from "./movies-list/add-movie/add-movie.component";
import { AddMovieCanDeactivateGuardService } from "./service/add-movie-can-deactivate-guard.service";
import { UserLoginComponent } from "./User Management/user-login/user-login.component";
import { PageNotFoundComponent } from "./page-not-found/page-not-found.component";
import { UserLogoutComponent } from "./User Management/user-logout/user-logout.component";
import { NgModule } from "@angular/core";
import { MultiplexListComponent } from "./multiplex-list/multiplex-list.component";
import { MultiplexDetailsComponent } from "./multiplex-list/multiplex-details/multiplex-details.component";
import { AddMultiplexComponent } from "./multiplex-list/add-multiplex/add-multiplex.component";
import { AddMultiplexCanDeactivateService } from "./service/multiplex/add-multiplex-can-deactivate.service";
import { MultiplexDetailsGuardService } from "./service/multiplex/multiplex-details-guard.service";
import { MultiplexListResolverService } from "./service/multiplex/multiplex-list-resolver.service";
import { AllotMoviesComponent } from "./allot-movies/allot-movies.component";
import { ViewAllocatedMultiplexComponent } from "./view-allocated-multiplex/view-allocated-multiplex.component";
import { AddScreensComponent } from "./multiplex-list/display-multiplex/add-screens/add-screens.component";
import { ViewScreensComponent } from "./multiplex-list/display-multiplex/view-screens/view-screens.component";
import { AuthGuardService } from "./service/auth-guard.service";


const appRoutes:Routes=[ 
    {path:"movieList",component: MoviesListComponent,resolve:{movieList:MovieListResolverService}/*,canActivate:[AuthGuardService]*/},
    {path:"movies/:id",component: MovieDetailsComponent,canActivate:[MovieDetailsGuardService]},
    {path:"multiplexList",component: MultiplexListComponent,resolve:{multiplexList:MultiplexListResolverService}/*,canActivate:[AuthGuardService]*/},
    {path:"multiplex/:mId",component: MultiplexDetailsComponent,canActivate:[MultiplexDetailsGuardService]},
    {path:"addMultiplex",component: AddMultiplexComponent,canDeactivate:[AddMultiplexCanDeactivateService],canActivate:[AuthGuardService]},
    {path:"editMultiplex/:mId",component: AddMultiplexComponent,canDeactivate:[AddMultiplexCanDeactivateService],canActivate:[AuthGuardService]},
    {path:"addMovie",component:AddMovieComponent,canDeactivate:[AddMovieCanDeactivateGuardService],canActivate:[AuthGuardService]},
    {path:"edit/:id",component:AddMovieComponent,canDeactivate:[AddMovieCanDeactivateGuardService],canActivate:[AuthGuardService]},
    {path:"addScreen/:mId",component:AddScreensComponent,canActivate:[AuthGuardService]},
    {path:"viewScreen/:mId",component: ViewScreensComponent},
    {path:"allot",component:AllotMoviesComponent,canActivate:[AuthGuardService]},
    {path:"viewAllocatedMultiplex/:id",component:ViewAllocatedMultiplexComponent},
    {path:"login",component:UserLoginComponent},
    {path:"",redirectTo:"/movieList",pathMatch:"full"},
    {path:"notfound",component:PageNotFoundComponent},
    {path:"logout",component:UserLogoutComponent,canActivate:[AuthGuardService]},
  ];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 
  
}
