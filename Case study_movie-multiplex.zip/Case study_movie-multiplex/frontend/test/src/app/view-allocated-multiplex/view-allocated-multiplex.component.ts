import { Component, OnInit } from '@angular/core';
import { AllotmentService } from '../service/allotment/allotment.service';
import { ActivatedRoute } from '@angular/router';
import { Multiplex } from '../models/multiplex.model';

@Component({
  selector: 'app-view-allocated-multiplex',
  templateUrl: './view-allocated-multiplex.component.html',
  styleUrls: ['./view-allocated-multiplex.component.css']
})
export class ViewAllocatedMultiplexComponent implements OnInit {

  multiplexes:Multiplex[];
  movieId:string;
  constructor(private _allotmentService:AllotmentService,private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(parameterMap=>{
      this.movieId=parameterMap.get('id');
      console.log(this.movieId);
    });
    this._allotmentService.getAllotedMultiplexes(this.movieId).subscribe(
      (data:any)=>{  
        console.log(data);
        this.multiplexes=data;  
      },
      err=>console.log(err)
    );
  }


}
