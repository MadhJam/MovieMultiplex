import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../service/authentication.service';

@Component({
  selector: 'app-user-logout',
  templateUrl: './user-logout.component.html',
  styleUrls: ['./user-logout.component.css']
})
export class UserLogoutComponent implements OnInit {

  constructor(private auth:AuthenticationService) { }

  // As soon as logout component is loaded , we want logout to happen
  ngOnInit() {
    // perform activities related to logout
    this.auth.logout();
    // navigate to login component
  }

}
