
export class Screen{
    constructor(public screenId:string,public screenName:string, public multiplexId:string){
        }
}