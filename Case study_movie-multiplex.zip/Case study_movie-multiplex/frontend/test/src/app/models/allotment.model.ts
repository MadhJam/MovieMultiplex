export class Allotment{
    constructor(public allotmentId:string,public movieId:string, public multiplexId:string,public screenId:string){
        }
}