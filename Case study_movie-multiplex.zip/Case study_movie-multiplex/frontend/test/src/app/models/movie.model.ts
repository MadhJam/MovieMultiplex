

export class Movie{
    constructor(public movieId:string,public movieName:string, public category:string, public producer:string,
        public director:string,public releaseDate:Date,public photoPath:string){
        
    }
}

