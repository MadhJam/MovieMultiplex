import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from "@angular/common";

import { NgModule } from '@angular/core';
import {RouterModule,Routes } from '@angular/router';
import { ReactiveFormsModule} from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { MoviesListComponent } from './movies-list/movies-list.component';
import { AddMovieComponent} from './movies-list/add-movie/add-movie.component';
import { UserLoginComponent } from './User Management/user-login/user-login.component';

import { DisplayMovieComponent } from './movies-list/display-movie/display-movie.component';
import { AddMovieCanDeactivateGuardService } from './service/add-movie-can-deactivate-guard.service';
import { MovieDetailsComponent } from './movies-list/movie-details/movie-details.component';
import { FormsModule } from '@angular/forms';
import { MovieListResolverService } from './service/movie-list-resolver.service';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { MovieDetailsGuardService } from './service/movie-details-guard.service';
import { AccordionComponent } from './shared/accordion/accordion.component';
import {HttpClientModule,HTTP_INTERCEPTORS} from '@angular/common/http';
import { HttpInterceptorService } from './service/http-interceptor.service';
import { UserLogoutComponent } from './User Management/user-logout/user-logout.component';
import { MultiplexListComponent } from './multiplex-list/multiplex-list.component';
import { MultiplexDetailsComponent } from './multiplex-list/multiplex-details/multiplex-details.component';
import { DisplayMultiplexComponent } from './multiplex-list/display-multiplex/display-multiplex.component';
import { AddMultiplexComponent } from './multiplex-list/add-multiplex/add-multiplex.component';
import { AllotMoviesComponent } from './allot-movies/allot-movies.component';
import { ViewAllocatedMultiplexComponent } from './view-allocated-multiplex/view-allocated-multiplex.component';
import { AddScreensComponent } from './multiplex-list/display-multiplex/add-screens/add-screens.component';
import { ViewScreensComponent } from './multiplex-list/display-multiplex/view-screens/view-screens.component';

//import { AuthGuardService } from './service/auth-guard.service';



@NgModule({
  declarations: [
    AppComponent,
    MoviesListComponent,
    AddMovieComponent,
    UserLoginComponent,
    DisplayMovieComponent,
    MovieDetailsComponent,
    PageNotFoundComponent,
    AccordionComponent,
    UserLogoutComponent,
    MultiplexListComponent,
    MultiplexDetailsComponent,
    DisplayMultiplexComponent,
    AddMultiplexComponent,
    AllotMoviesComponent,
    ViewAllocatedMultiplexComponent,
    AddScreensComponent,
    ViewScreensComponent,
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    BsDatepickerModule.forRoot(),
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    CommonModule,

  ],
  providers: [
   { provide : HTTP_INTERCEPTORS, 
    useClass:HttpInterceptorService, 
    multi:true
  }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
