import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { Multiplex } from '../models/multiplex.model';
import { Movie } from '../models/movie.model';
import { AllotmentService } from '../service/allotment/allotment.service';
import { MovieService } from '../service/movie.service';
import { MultiplexService } from '../service/multiplex/multiplex.service';


import { ScreenService } from '../service/screen/screen.service';
import { Allotment } from '../models/allotment.model';
import { Router } from '@angular/router';
@Component({
  selector: 'app-allot-movies',
  templateUrl: './allot-movies.component.html',
  styleUrls: ['./allot-movies.component.css']
})
export class AllotMoviesComponent implements OnInit {
  _allMovies: Observable<Movie[]>;  
   _allMultiplexes: Observable<Multiplex[]>; 
   _allScreens:Observable<Screen[]>;
  SelMultiplexId:string; 

  movie:string;
  multiplex:string;
  screen:string; 
  FormAllotment: any;  
  constructor(private formbulider: FormBuilder,private router:Router,private movieService:MovieService,private multiplexService:MultiplexService,private allotmentService:AllotmentService,private screenService:ScreenService) { }  
  FillMovies() 
  {  
    
    this._allMovies=this.movieService.getMovies();  
  } 
  FillMultiplex() 
  {    
    this._allMultiplexes=this.multiplexService.getMultiplexes();  
  }   
  FillScreen() 
  {   
    console.log("SelMultiplexId"+this.SelMultiplexId);
    this._allScreens =this.screenService.getScreensToAllot(this.SelMultiplexId);  
  }  
  ngOnInit() {  
    this.FormAllotment = this.formbulider.group({  
      MovieSelect: new FormControl('',Validators.required),  
      MultiplexSelect:new FormControl('',Validators.required),  
      ScreenSelect:new FormControl('',Validators.required),  
    });  
    this.FillMovies();  
  }
  save(){
    this.movie = this.FormAllotment.controls['MovieSelect'].value;
    this.multiplex = this.FormAllotment.controls['MultiplexSelect'].value;
    this.screen = this.FormAllotment.controls['ScreenSelect'].value;
    let allotment = new Allotment(null,this.movie,this.multiplex,this.screen);
    console.log(allotment);
    this.allotmentService.addMovieAllotment(allotment).subscribe(data=>
    {
    console.log(data); 
    this.FormAllotment.reset();
    this.router.navigate(['/movieList']);
    },
    error=>console.log(error));
         }
  }


