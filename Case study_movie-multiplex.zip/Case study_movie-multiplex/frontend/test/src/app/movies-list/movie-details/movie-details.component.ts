import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MovieService } from '../../service/movie.service';
import { Movie } from '../../models/movie.model';

@Component({
  selector: 'app-movie-details',
  templateUrl: './movie-details.component.html',
  styleUrls: ['./movie-details.component.css']
})
export class MovieDetailsComponent implements OnInit {
  movie:Movie;
  
  constructor(private route:ActivatedRoute,private movieService:MovieService) { }

  ngOnInit(): void {
   //this.route.paramMap.subscribe(params=>{
    const id=this.route.snapshot.params['id'];
    this.movieService.getMovie(id).subscribe(
      data=>{this.movie=data},
      err=>console.log(err)
    );
   }
 
}

 




