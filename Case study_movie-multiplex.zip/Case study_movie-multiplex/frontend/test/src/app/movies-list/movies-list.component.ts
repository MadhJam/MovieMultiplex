import { Component, OnInit } from '@angular/core';
import { Movie } from '../models/movie.model';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-movies-list',
  templateUrl: './movies-list.component.html',
  styleUrls: ['./movies-list.component.css']
})
export class MoviesListComponent implements OnInit {
  movies:Movie[];
  filteredMovies:Movie[];
  error:string;

  private _searchTerm:string;
  get searchTerm():string{
    return this._searchTerm;
  }
  set searchTerm(value:string){
    this._searchTerm=value;
    this.filteredMovies=this.filterMovies(value);
  }

  filterMovies(searchString:string){
    return this.movies.filter(movie=>movie.movieName.toLowerCase().indexOf(searchString.toLowerCase())!==-1);
  }
  constructor(private router:Router,private route:ActivatedRoute) {
    let resolvedData:Movie[]|string=this.route.snapshot.data['movieList'];
    if(Array.isArray(resolvedData)){
       this.movies=resolvedData;
    }
    else{
      this.error=resolvedData;
    }
    if(this.route.snapshot.queryParamMap.has('searchTerm')){
      this.searchTerm=this.route.snapshot.queryParamMap.get('searchTerm');
    }else{
     this.filteredMovies=this.movies;
    }
   }
   onDeleteNotification(id:string){
    let i=this.filteredMovies.findIndex(m=>m.movieId===id);
    if(i!==-1){
      this.filteredMovies.splice(i,1);
    }
   }
  ngOnInit(): void {
  
   
  }
  
    
  }


