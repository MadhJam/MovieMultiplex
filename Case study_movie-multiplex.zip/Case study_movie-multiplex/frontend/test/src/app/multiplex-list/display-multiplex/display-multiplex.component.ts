import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Multiplex } from '../../models/multiplex.model';
import { MultiplexService } from '../../service/multiplex/multiplex.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../service/authentication.service';

@Component({
  selector: 'app-display-multiplex',
  templateUrl: './display-multiplex.component.html',
  styleUrls: ['./display-multiplex.component.css']
})
export class DisplayMultiplexComponent implements OnInit {
  @Input() multiplex:Multiplex;
  @Input() searchTerm:string;
  @Output() notifyDelete:EventEmitter<string>=new EventEmitter<string>();
  showForm:boolean;
  confirmDelete=false;
 
   constructor(private router:Router,private multiplexService:MultiplexService,public auth : AuthenticationService) {
     //console.log("MultiplexValue:"+this.multiplex);
    }
 
   ngOnInit(): void {
     
   }
 
   viewMultiplex(){
    console.log("MultiplexValueInitMultID:"+this.multiplex.multiplexId);
     this.router.navigate(['/multiplex',this.multiplex.multiplexId],{
       queryParams:{'searchTerm':this.searchTerm}
     });
   }
   editMultiplex(multiplexId:string){
     this.router.navigate(['/editMultiplex',multiplexId]);
   }
   deleteMultiplex(){
     this.multiplexService.deleteMultiplex(this.multiplex.multiplexId).subscribe(()=>console.log(`Multiplex with ID=${this.multiplex.multiplexId} deleted`),
     (err)=>console.log(err)
     );
     this.notifyDelete.emit(this.multiplex.multiplexId);
   }
   addScreens(multiplexId:string){
   
    this.router.navigate(['/addScreen',multiplexId]);
   }
   viewScreen(multiplexId:string){
    this.router.navigate(['/viewScreen',multiplexId]);
   }

}
