import { Component, OnInit } from '@angular/core';
import { Screen } from '../../../models/screen.model';

import { ScreenService } from '../../../service/screen/screen.service';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-view-screens',
  templateUrl: './view-screens.component.html',
  styleUrls: ['./view-screens.component.css']
})
export class ViewScreensComponent implements OnInit {
  screens:Screen[];
  multiplexId:string;
  constructor(private _screenService:ScreenService,private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(parameterMap=>{
      this.multiplexId=parameterMap.get('mId');
      console.log(this.multiplexId);
    });
    this._screenService.getScreen(this.multiplexId).subscribe(
      (data:any)=>{  
        console.log(data);
        this.screens=data;  
      },
      err=>console.log(err)
    );
  }
  

}
