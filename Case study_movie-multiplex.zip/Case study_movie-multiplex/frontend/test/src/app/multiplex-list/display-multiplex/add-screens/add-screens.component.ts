import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ScreenService } from '../../../service/screen/screen.service';
import { Screen } from '../../../models/screen.model';

@Component({
  selector: 'app-add-screens',
  templateUrl: './add-screens.component.html',
  styleUrls: ['./add-screens.component.css']
})
export class AddScreensComponent implements OnInit {
  multiplexId:string;
  screenName:string;
  screen:Screen;


  addScreenForm: FormGroup
  constructor(formBuilder : FormBuilder,private router:Router,private _screenService:ScreenService,private route:ActivatedRoute) {
    this.addScreenForm = formBuilder.group({
      "screenName" : new FormControl('',Validators.required)
    });
   }

  ngOnInit(): void {
    this.route.paramMap.subscribe(parameterMap=>{
      this.multiplexId=parameterMap.get('mId');
    });
  }

  get f(){
    return this.addScreenForm.controls;
  }

  save(){
    this.screenName = this.addScreenForm.controls['screenName'].value;
    this._screenService.addScreen(this.multiplexId,this.screenName).subscribe(data=>
    {
    console.log(data);   
    this.addScreenForm.reset();
    this.router.navigate(['/multiplexList']);
    },
    error=>console.log(error));
    }
}



