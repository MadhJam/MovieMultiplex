import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Multiplex } from '../models/multiplex.model';

@Component({
  selector: 'app-multiplex-list',
  templateUrl: './multiplex-list.component.html',
  styleUrls: ['./multiplex-list.component.css']
})
export class MultiplexListComponent implements OnInit {

  multiplexes:Multiplex[];
  filteredMultiplexes:Multiplex[];
  error:string;

  private _searchTerm:string;
  get searchTerm():string{
    return this._searchTerm;
  }
  set searchTerm(value:string){
    this._searchTerm=value;
    this.filteredMultiplexes=this.filterMultiplexes(value);
  }

  filterMultiplexes(searchString:string){
    return this.multiplexes.filter(multiplex=>multiplex.multiplexName.toLowerCase().indexOf(searchString.toLowerCase())!==-1);
  }
  constructor(private router:Router,private route:ActivatedRoute) {
    let resolvedData:Multiplex[]|string=this.route.snapshot.data['multiplexList'];
    if(Array.isArray(resolvedData)){
       this.multiplexes=resolvedData;
    }
    else{
      this.error=resolvedData;
    }
    if(this.route.snapshot.queryParamMap.has('searchTerm')){
      this.searchTerm=this.route.snapshot.queryParamMap.get('searchTerm');
    }else{
     this.filteredMultiplexes=this.multiplexes;
    }
   }
   onDeleteNotification(multiplexId:string){
    let i=this.filteredMultiplexes.findIndex(m=>m.multiplexId===multiplexId);
    if(i!==-1){
      this.filteredMultiplexes.splice(i,1);
    }
   }
  ngOnInit(): void {
  
   
  }
  

}
