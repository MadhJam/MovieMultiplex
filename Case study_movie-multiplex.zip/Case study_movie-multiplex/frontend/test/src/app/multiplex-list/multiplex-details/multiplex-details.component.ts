import { Component, OnInit } from '@angular/core';
import { Multiplex } from '../../models/multiplex.model';
import { ActivatedRoute } from '@angular/router';
import { MultiplexService } from '../../service/multiplex/multiplex.service';

@Component({
  selector: 'app-multiplex-details',
  templateUrl: './multiplex-details.component.html',
  styleUrls: ['./multiplex-details.component.css']
})
export class MultiplexDetailsComponent implements OnInit {
  multiplex:Multiplex;
  
  constructor(private route:ActivatedRoute,private multiplexService:MultiplexService) { }

  ngOnInit(): void {
   //this.route.paramMap.subscribe(params=>{
    const multiplexId=this.route.snapshot.params['mId'];
    this.multiplexService.getMultiplex(multiplexId).subscribe(
      data=>{this.multiplex=data},
      err=>console.log(err)
    );
   }

}
